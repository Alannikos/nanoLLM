import torch
from torch.utils.data import Dataset
from transformers import BertTokenizer

class MTDataset(Dataset):
    def __init__(self,
        max_len: int,
        en_tokenizer_path: str = None,
        zh_tokenizer_path: str = None,
        mode: str = "train"
    ):
        """构造函数

        Parameters
        ----------
        max_len : int
            指定padding的长度
        en_tokenizer_path : str
            英语tokenizer路径（如 'bert-base-uncased'）
        zh_tokenizer_path : str
            中文tokenizer路径（如 'bert-base-chinese'）
        mode : str, optional
            指定当前模式是训练还是测试, by default "train"
        """

        assert mode in ['train', 'valid', 'test'], "mode must in ['train', 'valid', 'test']"

        print(f"load {mode} data")

        self.mode = mode
        self.max_len = max_len
        # 加载tokenizer
        self.en_tokenizer = BertTokenizer.from_pretrained(en_tokenizer_path)
        self.zh_tokenizer = BertTokenizer.from_pretrained(zh_tokenizer_path)

        # 获取特殊token的id
        self.start_token_id = self.zh_tokenizer.bos_token_id or self.zh_tokenizer.cls_token_id
        self.end_token_id = self.zh_tokenizer.eos_token_id or self.zh_tokenizer.sep_token_id
        self.pad_token_id = self.zh_tokenizer.pad_token_id

        # 验证英语tokenizer的特殊token是否一致
        assert self.en_tokenizer.pad_token_id == self.pad_token_id, "两个tokenizer的pad_token_id应该一致！"

        # 读取原始句子
        self.sentences_zh = self._get_raw_data(f"./data/{mode}.zh.tok")
        self.sentences_en = self._get_raw_data(f"./data/{mode}.en.tok")
        
        # 使用tokenizer批量处理数据，包括添加特殊token、padding和truncation
        self.data_en = self.en_tokenizer(self.sentences_en, add_special_tokens=True, padding="max_length", 
                                         truncation=True, max_length=self.max_len, return_tensors='pt')['input_ids']
        self.data_zh = self.zh_tokenizer(self.sentences_zh, add_special_tokens=True, padding="max_length", 
                                         truncation=True, max_length=self.max_len, return_tensors='pt')['input_ids']
        
        # 预计算每个zh序列的len_zh（end_token的位置，作为target的有效长度）
        self.len_zh_list = []
        for zh in self.data_zh:
            # 找到end_token_id的位置（假设只有一个，且总是存在）
            sep_indices = (zh == self.end_token_id).nonzero(as_tuple=True)[0]
            assert len(sep_indices) > 0, "end_token_id not found in zh sequence"
            sep_index = sep_indices[0].item()  # 取第一个（唯一）的位置
            self.len_zh_list.append(sep_index)

    def _get_raw_data(self, file_path: str):
        """读取原始数据文件，返回句子列表

        Parameters
        ----------
        file_path : str
            文本数据的路径
        """
        with open(file_path, "r", encoding="utf-8") as f:
            data = [x.strip() for x in f.readlines()]
        return data

    def __len__(self):
        return len(self.sentences_en)

    def getVocabZhLen(self):
        return self.zh_tokenizer.vocab_size

    def getVocabEnLen(self):
        return self.en_tokenizer.vocab_size

    def __getitem__(self, index):
        """按照index返回对应的en和zh数据
        Parameters
        ----------
        index : int
            数据索引
        """
        zh = self.data_zh[index]
        en = self.data_en[index]
        len_zh = self.len_zh_list[index]

        # 训练模式：返回 (encoder输入, decoder输入, 目标, 长度)
        # 验证/测试模式：返回 (encoder输入, 完整zh序列, 完整zh序列, 长度)
        if self.mode == "train":
            return en, zh[:-1], zh[1:], len_zh
        else:
            return en, zh, zh, len_zh